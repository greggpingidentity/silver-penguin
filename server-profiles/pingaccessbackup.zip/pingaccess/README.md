# Purpose
This directory contains the data that is required to customize pingaccess containers to taste

## Credentials
User: Administrator
Password: 2FederateM0re
